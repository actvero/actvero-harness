# 宿主接入

本文供 ACTVERO 桌面开发者在隔离工作区加载游戏模式并复用原生会话、专家和语音。

## Electron 与 Loader

主窗口创建后调用 `/desktop` 的 `installGameMode(mainWindow, { restoreBackdrop, report })`。返回的释放函数撤销 IPC、键盘监听并恢复窗口；窗口关闭也会释放。`restoreBackdrop` 由宿主恢复常规窗口材质。当前控制器仅支持一个主窗口。

在受信任的 `dsh-app://app/` 主 frame 中，用 `/preload` 的 `createGameModeBridge()` 暴露 `window.actveroGameMode`。Main 同时验证 sender、mainFrame 和来源；外部网页与子 frame 不获得此能力。macOS 进入模式时请求输入监控授权；快捷键冲突或系统读取失败会报告错误并尝试恢复窗口。

桌面和 Web bundle 的 resolver 依赖固定的插件包。桌面 profile 挂载根 Host 插件，行 ID 为 `actvero-game-mode`；根插件通过原生 Settings 保存配置。DSH Loader 按包内 `dsh.client` 声明加载 `/client`。普通浏览器没有桌面 bridge，不注册游戏模式入口。

## 原生服务

客户端提供 `ctx.gameMode`，在原生聊天标题栏、临时 overlay 和设置中注册贡献。界面通过 Slot 注入 hooks 读取快照，生命周期释放撤下注册。聊天消息和编辑器不由本插件复制或管理。

- `ctx.actveroExpertLauncher` 提供可选专家目录和激活入口。激活验证当前目录、查找同工作区最近会话；找不到时复用原生选择、授权与依赖准备。取消信号阻止迟到导航。
- `ctx.voiceInputControls` 按 Session 定位已经挂载的原生语音控件。该可选服务未加载或未准备时显示原生配置提示，不启动替代识别器。录音使用按下时的会话与原编辑器修订号，已取消结果不能进入草稿。
- `ctx.theme` 提供临时 token 覆盖，退出后移除覆盖，保留用户主题偏好。原生布局负责侧栏展开状态。
- `ctx.configForms` 持久化设置，提交携带读取时的修订号；并发修改被拒绝。模式开启时不能变更配置，从专家面板进入配置会先退出模式。

账户归属发生变化时取消录音和专家导航，并退出模式。隐藏窗口不终止会话任务，也不主动释放键盘按住录音；退出模式会取消录音。

## 配置与输入

GUI 提供四个专家槽位、三个功能键、交互显隐快捷键、毛玻璃不透明度、窗口占屏比例和宽高比。默认槽位、手柄按钮及键盘采样周期由 Host 配置拥有，字段和范围以 `src/config.ts` 与 `src/settings.ts` 为准。重复快捷键、非法按钮和越界参数在应用前拒绝。

专家面板支持方向键、确认、返回、Escape、外部点击和焦点恢复。窄窗口将标题栏操作收进原生菜单；槽位不常驻聊天区域。

标准 Gamepad 只在原生窗口拥有前台焦点时采样。失焦、断开、设备切换和卸载会重置边沿并取消录音。后台手柄需要另行提供 macOS/Windows 系统监听与硬件验收，不能用关闭 backgroundThrottling 代替。

## 验收范围

使用隔离 `dsh` profile，保留用户已安装应用及真实数据。分别检查窗口进入、按住查看、显隐和退出恢复；快捷键占用；麦克风拒绝和授权延迟；专家切换与账户变化；手柄热插拔及游戏全屏行为。具体已执行结果见[验证记录](validation.md)。
