/** 原生聊天的游戏模式扩展；不拥有消息、转写或专家授权。 */
import type { Context } from '@deepseek-ai/cordis';
import { GameMode } from '../controller.js';
declare module '@deepseek-ai/cordis' {
    interface Context {
        gameMode: GameMode;
    }
}
export declare const inject: string[];
/** 挂载到原生会话与设置槽位。 @param ctx 当前客户端生命周期。 */
export declare function apply(ctx: Context): void;
