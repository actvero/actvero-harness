export declare const NS = "actvero.game-mode";
export declare const zh: {
    title: string;
    enter: string;
    exit: string;
    hide: string;
    experts: string;
    settings: string;
    close: string;
    empty: string;
    configure: string;
    choose: string;
    slots: string;
    slotsHelp: string;
    opacity: string;
    scale: string;
    ratio: string;
    save: string;
    saved: string;
    shortcuts: string;
    peek: string;
    talk: string;
    toggle: string;
    recording: string;
    transcribing: string;
    starting: string;
    loading: string;
    retry: string;
    pad: string;
    padHelp: string;
    voiceHelp: string;
    leaveFirst: string;
    desktopOnly: string;
    failed: string;
    unavailable: string;
    voiceUnavailable: string;
    conversationRequired: string;
    permission: string;
    conflict: string;
    invalid: string;
    fullScreen: string;
    pending: string;
};
export declare const en: Record<keyof typeof zh, string>;
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        'actvero.game-mode': keyof typeof zh;
    }
}
