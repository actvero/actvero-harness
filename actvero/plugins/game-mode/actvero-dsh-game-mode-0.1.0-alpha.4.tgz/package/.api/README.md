# DSH 编译声明快照

本文供维护插件与 ACTVERO 接口兼容性的开发者使用。`dsh-declarations.tar.gz` 保存配套 Harness 已编译的 TypeScript 声明，`tsconfig.api.json` 映射其模块入口；生成目录不提交。快照包含本次新增的专家启动与原生语音控制声明。

`pnpm typecheck` 和 `pnpm build` 只解压仓库内快照，不读取相邻工作区。更新接口时，先在对应 Harness 修订完成 artifacts 构建，再显式运行 `python3 scripts/capture-api.py <Harness工作区绝对路径>`。归档固定文件顺序、时间与所有者，避免重复采集产生无意义差异。检查并提交归档与映射后运行 `pnpm check`。

此快照只用于编译。运行时仍由 DSH Loader 提供服务，不能以声明存在代替服务安装或版本兼容检查。配套宿主的文件包、锁文件和集成修改必须一起交付。
