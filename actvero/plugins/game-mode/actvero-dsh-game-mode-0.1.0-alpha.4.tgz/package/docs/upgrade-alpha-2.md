# 从 alpha.1 迁移到 alpha.2

本文面向使用首版核心接口的宿主开发者。alpha.2 将根入口改为 Host 设置插件，并增加 DSH Client Loader 入口。

原先以 `gameModeHost` 注入根插件的接法不再适用。宿主应挂载 ID 为 `actvero-game-mode` 的 Host 行，让 Loader 加载 `/client`，并提供[接入文档](integration.md)所列的原生服务。仅使用状态机的测试或嵌入方可继续从 `/controller` 创建 `GameMode`，传入 `GameHost`。

Electron 的 `/desktop` 和 `/preload` 入口保持原有职责；升级还需配套原生 `actveroExpertLauncher` 和 `voiceInputControls` 服务。旧版已安装应用缺少这些服务，不能只替换插件包完成升级。此次变更不迁移会话日志。
