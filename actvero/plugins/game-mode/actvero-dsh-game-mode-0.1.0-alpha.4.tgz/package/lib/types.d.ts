/** 游戏模式在原生窗口和客户端之间传递的公开数据。 */
export type GameKey = 'F1' | 'F2' | 'F3' | 'F4' | 'F5' | 'F6' | 'F7' | 'F8' | 'F9' | 'F10' | 'F11' | 'F12';
/** 持久化的插件偏好；启用状态不跨启动恢复。 */
export interface GameSettings {
    keyboardPollMs: number;
    stickThreshold: number;
    opacity: number;
    scale: number;
    aspectRatio: number;
    peekKey: GameKey;
    expertKey: GameKey;
    voiceKey: GameKey;
    toggleShortcut: string;
    slots: string[];
    defaultSlot: number;
    gamepad: boolean;
    voiceButton: number;
    expertButton: number;
    toggleButton: number;
}
/** 原生输入只暴露已配置动作，不传递其他按键。 */
export type GameInput = {
    action: 'peek' | 'voice';
    down: boolean;
} | {
    action: 'experts';
} | {
    action: 'cancel';
};
/** 原生进程的事件消息；错误不携带按键或会话内容。 */
export type GameEvent = GameInput | {
    action: 'state';
    state: GameWindowState;
} | {
    action: 'error';
    code: string;
};
/** 当前窗口的游戏模式状态。 */
export interface GameWindowState {
    enabled: boolean;
    visible: boolean;
    material: 'vibrancy' | 'acrylic' | 'solid';
}
/** 仅在受信任的 ACTVERO 顶层页面提供的原生操作。 */
export interface GameDesktopBridge {
    configure(settings: GameSettings): Promise<void>;
    enable(enabled: boolean): Promise<GameWindowState>;
    show(): Promise<void>;
    hide(): Promise<void>;
    state(): Promise<GameWindowState>;
    subscribe(listener: (event: GameEvent) => void): () => void;
}
declare global {
    interface Window {
        actveroGameMode?: GameDesktopBridge;
    }
}
