/** 已保存的 Electron 快捷键的可读表示。
 * @param value 保存的组合键。 @param mac 是否使用 macOS 标记。 @returns 依序显示的键帽。
 */
export declare function shortcutKeys(value: string, mac: boolean): string[];
/** @param index 标准 Gamepad API 按键编号。 @returns Xbox / PlayStation 对应标记。 */
export declare function padKey(index: number): string;
/** 从带修饰键的字母或数字生成受支持的快捷键；其他按键不修改配置。
 * @param event 当前按键。 @param mac 是否使用 macOS 修饰键。 @returns 有效组合或 null。
 */
export declare function recordedShortcut(event: Pick<KeyboardEvent, 'key' | 'code' | 'metaKey' | 'ctrlKey' | 'altKey' | 'shiftKey'>, mac: boolean): string | null;
