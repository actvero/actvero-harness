/** 设置解析与窗口尺寸运算，不依赖浏览器或 Electron。 */
import type { GameSettings } from './types.js';
/** 首次安装使用的显式配置。 */
export declare const initialSettings: GameSettings;
/** 校验跨进程设置，拒绝重复热键和越界值。
 * @param value IPC 输入。
 * @returns 可供原生窗口使用的设置副本。
 */
export declare function parseSettings(value: unknown): GameSettings;
/** 在当前屏幕可用区域按比例居中，包含负坐标副屏。
 * @param area 显示器可用区域。
 * @param settings 窗口比例设置。
 * @returns 不超出可用区域的整数边界。
 */
export declare function centeredBounds(area: {
    x: number;
    y: number;
    width: number;
    height: number;
}, settings: Pick<GameSettings, 'scale' | 'aspectRatio'>): {
    x: number;
    y: number;
    width: number;
    height: number;
};
