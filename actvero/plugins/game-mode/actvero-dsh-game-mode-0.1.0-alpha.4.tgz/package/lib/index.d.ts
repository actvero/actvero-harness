/** Host 入口；设置仍由 DSH 原生文档保存。 */
import type { Context } from '@deepseek-ai/cordis';
export { Config } from './config.js';
export declare const inject: string[];
/** 注册原生设置。 @param ctx 当前 Host 插件。 */
export declare function apply(ctx: Context): void;
export type { GameHost, ConversationRef, VoiceHold } from './host.js';
export type { GameSnapshot } from './controller.js';
export type { GameSettings, GameDesktopBridge, GameEvent } from './types.js';
