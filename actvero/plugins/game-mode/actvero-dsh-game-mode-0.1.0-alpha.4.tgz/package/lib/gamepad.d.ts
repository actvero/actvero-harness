/** 标准手柄的按键边沿检测；不绕过系统的后台输入限制。 */
import type { GameSettings } from './types.js';
/** 控制器向宿主派发的语义动作。 */
export type PadAction = 'voice-down' | 'voice-up' | 'cancel' | 'experts' | 'toggle' | 'previous' | 'next' | 'confirm' | 'back';
/** 单个手柄采样；连接时先建立基线，断开只取消。 */
export declare class GamepadEdges {
    #private;
    private readonly settings;
    private readonly emit;
    /** @param settings 按键配置。 @param emit 动作接收器。 */
    constructor(settings: GameSettings, emit: (action: PadAction) => void);
    /** 前台客户端采样；失焦或断开时传 null。
     * @param pad 已授权的标准手柄。
     */
    sample(pad: Pick<Gamepad, 'mapping' | 'buttons' | 'axes'> | null): void;
    /** 断开、失焦或停用时取消，绝不转写发送。 */
    reset(): void;
}
