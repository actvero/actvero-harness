/** 游戏模式状态机；隐藏窗口不会终止原生会话。 */
import type { GameHost } from './host.js';
import type { GameSettings } from './types.js';
/** 可由 DSH 注入 hooks 直接订阅的界面状态。 */
export interface GameSnapshot {
    readonly phase: 'off' | 'entering' | 'on' | 'leaving';
    readonly picker: boolean;
    readonly slot: number;
    readonly selecting: boolean;
    readonly voice: 'idle' | 'starting' | 'recording' | 'transcribing';
}
/** 一个实例对应一个受信任的桌面主窗口。 */
export declare class GameMode {
    #private;
    private readonly host;
    /** 当前已验证设置。 */
    get settings(): GameSettings;
    /** @param host 原生功能提供者。 @param settings 插件偏好。 */
    constructor(host: GameHost, settings: GameSettings);
    /** 只在模式关闭时应用已保存的配置。 @param settings 新配置。 */
    configure(settings: GameSettings): void;
    /** @returns 在下一次变更之前保持引用不变的快照。 */
    getSnapshot: () => GameSnapshot;
    /** @param listener 状态通知。 @returns 解除订阅函数。 */
    subscribe: (listener: () => void) => (() => void);
    /** 串行切换，避免快速开关残留置顶或快捷键。
     * @param enabled 目标状态。 @returns 模式切换完成；失败保留异常。
     */
    setEnabled(enabled: boolean): Promise<void>;
    /** 隐藏原窗口，保持后台任务运行。 @returns 原生隐藏操作完成。 */
    hide(): Promise<void>;
    /** 显示原窗口。 @returns 原生窗口可见。 */
    show(): Promise<void>;
    /** 打开临时选择器；录音时不切换专家。 */
    openPicker(): void;
    /** 关闭选择器并取消未完成的切换。 */
    closePicker(): void;
    /** @param delta 前后移动的槽位数。 */
    moveSlot(delta: number): void;
    /** 使用槽位，保持原生授权和会话归属。
     * @param index 槽位下标。 @returns 专家切换完成。
     */
    selectSlot(index?: number): Promise<void>;
    /** 按下语音键；多个设备共享一次录音。 @param source 稳定设备标识。 */
    pressVoice(source: string): void;
    /** 最后一个设备释放后提交；授权未完成的短按直接取消。
     * @param source 与按下时相同的标识。
     */
    releaseVoice(source: string): void;
    /** 设备断开、退出或身份变化时取消；永不发送。 */
    cancelVoice(): void;
    /** 释放订阅并等待窗口恢复；可重复调用。 @returns 插件停止。 */
    dispose(): Promise<void>;
}
