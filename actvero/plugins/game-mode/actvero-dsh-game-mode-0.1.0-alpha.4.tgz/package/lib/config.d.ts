/** 原生 Host 设置元数据；跨字段检查在客户端与 IPC 执行前完成。 */
import z from '@deepseek-ai/schemastery';
/** 所有用户偏好由 DSH 设置文档持久化，volatile 更新不重建服务。 */
export declare const Config: z<Schemastery.ObjectS<NoInfer<{
    keyboardPollMs: z<number, number, "volatile-defined">;
    stickThreshold: z<number, number, "volatile-defined">;
    opacity: z<number, number, "volatile-defined">;
    scale: z<number, number, "volatile-defined">;
    aspectRatio: z<number, number, "volatile-defined">;
    peekKey: z<string, string, "volatile-defined">;
    expertKey: z<string, string, "volatile-defined">;
    voiceKey: z<string, string, "volatile-defined">;
    toggleShortcut: z<string, string, "volatile-defined">;
    slots: z<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
    defaultSlot: z<number, number, "volatile-defined">;
    gamepad: z<boolean, boolean, "volatile-defined">;
    voiceButton: z<number, number, "volatile-defined">;
    expertButton: z<number, number, "volatile-defined">;
    toggleButton: z<number, number, "volatile-defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    keyboardPollMs: z<number, number, "volatile-defined">;
    stickThreshold: z<number, number, "volatile-defined">;
    opacity: z<number, number, "volatile-defined">;
    scale: z<number, number, "volatile-defined">;
    aspectRatio: z<number, number, "volatile-defined">;
    peekKey: z<string, string, "volatile-defined">;
    expertKey: z<string, string, "volatile-defined">;
    voiceKey: z<string, string, "volatile-defined">;
    toggleShortcut: z<string, string, "volatile-defined">;
    slots: z<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
    defaultSlot: z<number, number, "volatile-defined">;
    gamepad: z<boolean, boolean, "volatile-defined">;
    voiceButton: z<number, number, "volatile-defined">;
    expertButton: z<number, number, "volatile-defined">;
    toggleButton: z<number, number, "volatile-defined">;
}>>, "plain">;
