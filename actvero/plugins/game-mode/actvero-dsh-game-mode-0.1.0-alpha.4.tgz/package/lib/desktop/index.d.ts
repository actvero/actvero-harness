/** Electron 主进程：原生窗口材质、布局和全局功能键。 */
import { type BrowserWindow } from 'electron';
/** 宿主窗口材质无法从 Electron 读取，必须由拥有者提供恢复函数。 */
export interface DesktopOptions {
    /** 恢复宿主正常主题的 vibrancy、backgroundMaterial 和标题栏；可重复调用。 */
    restoreBackdrop(): void;
    /** 原生生命周期异常归宿主日志，不包含用户输入。 */
    report(error: unknown): void;
}
/** 安装到唯一主窗口；仅接受该窗口受信任顶层页面的 IPC。
 * @param window ACTVERO 主窗口。
 * @param options 原材质恢复与错误报告。
 * @returns 释放 IPC、键盘读取器并恢复窗口的函数。
 */
export declare function installGameMode(window: BrowserWindow, options: DesktopOptions): () => void;
