import type { GameDesktopBridge } from '../types.js';
/** 创建 bridge；由宿主负责校验页面来源并调用 contextBridge。
 * @returns 游戏模式原生能力，不暴露任意 IPC。
 */
export declare function createGameModeBridge(): GameDesktopBridge;
