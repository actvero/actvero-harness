import type { GameKey } from '../types.js';
/** 加载系统键状态查询；macOS 只在启用时请求输入监控权限。
 * @param platform 当前操作系统。
 * @returns 功能键状态读取器及幂等释放函数。
 */
export declare function openKeys(platform: NodeJS.Platform): {
    pressed: (key: GameKey) => boolean;
    close: () => void;
};
