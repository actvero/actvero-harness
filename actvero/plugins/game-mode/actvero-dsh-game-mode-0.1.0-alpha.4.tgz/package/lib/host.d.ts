/** 宿主负责连接原生聊天服务，不能通过 DOM 点击或复制消息实现。 */
import type { GameDesktopBridge, GameSettings } from './types.js';
/** 不透明会话引用；宿主操作前验证账户、工作区与会话仍可访问。 */
export interface ConversationRef {
    readonly sessionId: string;
    readonly workspaceId: string;
    readonly ownerId: string;
}
/** 一次由 DSH 原生语音插件拥有的录音；取消不能提交。 */
export interface VoiceHold {
    /** 走原生转写与提交；草稿变化时保留转写供用户确认。 */
    release(): Promise<void>;
    /** 立即终止录音或转写，不修改草稿、不发送；可重复调用。 */
    cancel(): void;
}
/** ACTVERO 客户端提供的原生功能；缺少此服务时插件保持待激活。 */
export interface GameHost {
    desktop: GameDesktopBridge;
    /** @returns 当前原生主对话；没有可用会话时为 null。 */
    currentConversation(): ConversationRef | null;
    /** 使用 DSH 语音配置；授权期间也必须响应取消。
     * @param conversation 按下时捕获的会话，不跟随标签切换。
     * @param signal 退出模式、取消录音或卸载的信号。
     * @returns 此次录音；release 转写并通过原生输入提交。
     */
    beginVoice(conversation: ConversationRef, signal: AbortSignal): Promise<VoiceHold>;
    /** 恢复该专家在同一账户、工作区内的最近会话；不存在时走原生专家选择流程。
     * @param expertId 用户绑定的专家 ID。
     * @param from 操作发生时的原生会话。
     * @param signal 退出模式或身份变化时取消切换。
     */
    activateExpert(expertId: string, from: ConversationRef, signal: AbortSignal): Promise<void>;
    /** 临时应用深灰毛玻璃和原生聊天布局。
     * @param settings 本次模式设置。
     * @returns 幂等恢复原主题、侧栏与焦点的函数。
     */
    present(settings: GameSettings): () => void;
    /** 向原生通知区域报告失败；不包含语音或会话内容。
     * @param code 可本地化错误码。
     * @param error 保留供诊断的原始异常。
     */
    report(code: string, error: unknown): void;
}
