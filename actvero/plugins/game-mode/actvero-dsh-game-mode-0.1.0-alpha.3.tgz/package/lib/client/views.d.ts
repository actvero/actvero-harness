import type { HostObservable, InjectFace, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ConfigFormSnapshot } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { GameSnapshot } from '../controller.js';
import type { GameSettings } from '../types.js';
import type { ExpertShortcut } from '@actvero/dsh-experts/client';
import { NS } from './locales.js';
export interface GameInjected {
    desktop: boolean;
    hooks: {
        mode: HostObservable<GameSnapshot>;
        config: HostObservable<ConfigFormSnapshot<GameSettings>>;
        catalog: HostObservable<{
            rows: ExpertShortcut[];
            busy: boolean;
            failed: boolean;
        }>;
        notice: HostObservable<{
            text: string;
            revision: number;
        } | null>;
    };
    toggle(): void;
    hide(): void;
    pick(): void;
    close(): void;
    move(delta: number): void;
    select(index?: number): void;
    openSettings(): void;
    refresh(): void;
    save(settings: GameSettings, revision: number | undefined): Promise<void>;
    clearNotice(): void;
}
type Props = InjectFace<GameInjected> & PropsLocale<typeof NS>;
export declare function Controls(props: Props): import("react/jsx-runtime").JSX.Element | null;
export declare function Overlay(props: Props): import("react/jsx-runtime").JSX.Element;
export declare function Settings(props: Props): import("react/jsx-runtime").JSX.Element;
/** 不支持游戏模式的宿主保留可发现的说明入口。 */
export declare function UnavailableControls(props: PropsLocale<typeof NS> & {
    openSettings(): void;
}): import("react/jsx-runtime").JSX.Element;
/** 缺少桌面接线或专家服务时持续显示恢复指引。 */
export declare function UnavailableSettings(props: PropsLocale<typeof NS>): import("react/jsx-runtime").JSX.Element;
export {};
